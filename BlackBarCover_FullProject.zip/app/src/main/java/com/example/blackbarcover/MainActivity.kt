package com.example.blackbarcover

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart = findViewById<Button>(R.id.btnStart)
        val edtX = findViewById<EditText>(R.id.edtX)
        val edtW = findViewById<EditText>(R.id.edtW)

        btnStart.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                return@setOnClickListener
            }
            val x = edtX.text.toString().toIntOrNull() ?: 0
            val w = edtW.text.toString().toIntOrNull() ?: 20
            val svc = Intent(this, OverlayService::class.java)
            svc.putExtra("bar_x", x)
            svc.putExtra("bar_w", w)
            startService(svc)
        }
    }
}
