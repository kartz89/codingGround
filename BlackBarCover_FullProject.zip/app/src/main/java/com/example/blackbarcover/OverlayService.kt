package com.example.blackbarcover

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class OverlayService : Service() {
    private var barView: View? = null
    private var wm: WindowManager? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val x = intent?.getIntExtra("bar_x", 0) ?: 0
        val w = intent?.getIntExtra("bar_w", 20) ?: 20

        if (barView != null) {
            wm?.removeView(barView)
            barView = null
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.START or Gravity.TOP
        params.x = x
        params.y = 0

        val view = View(this)
        view.setBackgroundColor(0xFF000000.toInt())
        wm?.addView(view, params)
        barView = view

        return START_STICKY
    }

    override fun onDestroy() {
        if (barView != null) {
            wm?.removeView(barView)
            barView = null
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
