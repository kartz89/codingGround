#include <stdio.h>

#define MAX_DEVICES     2
#define MAX_MSG         4
#define MAX_DATA_SIZE   8

int Data0[MAX_DATA_SIZE] = { 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48};
int Data1[MAX_DATA_SIZE] = { 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58};
int Data2[MAX_DATA_SIZE] = { 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68};
int Data3[MAX_DATA_SIZE] = { 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78};

int Data4[MAX_DATA_SIZE] = { 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88};
int Data5[MAX_DATA_SIZE] = { 0x91, 0x92, 0x93, 0x94, 0x95 ,0x96 ,0x97 ,0x98};
int Data6[MAX_DATA_SIZE] = { 0x17, 0x18, 0x19, 0x20, 0x21, 0x22, 0x23, 0x24};
int Data7[MAX_DATA_SIZE] = { 0x25, 0x26, 0x27, 0x28, 0x29, 0x30, 0x31, 0x32};

int deviceState[MAX_DEVICES];

typedef struct tConfig
{
    int     nTxMsg;
    int     nRxMsg;
    int     *pTx[MAX_MSG];
    int     *pRx[MAX_MSG];
}tConfig;

int funcTx(int deviceNum, tConfig *pConfig[]);

int main()
{
    int     i, j, retVal;
    tConfig oConfig[MAX_DEVICES], *pConfig[MAX_DEVICES];
    
    for(i=0; i<MAX_DEVICES; i++)
    {
        pConfig[i] = &oConfig[i];
    }
    
    pConfig[0]->pTx[0] = Data0;
    pConfig[0]->pTx[1] = Data1;
    pConfig[0]->pTx[2] = Data2;
    pConfig[0]->pTx[3] = Data3;
    
    pConfig[1]->pTx[0] = Data4;
    pConfig[1]->pTx[1] = Data5;
    pConfig[1]->pTx[2] = Data6;
    pConfig[1]->pTx[3] = Data7;
    
    retVal = funcTx(0, pConfig);
    
    printf("Hello, World!\n");

    return 0;
}

int funcTx(int deviceNum, tConfig *pConfig[])
{
    int i,j,k;
    
    for(i=0; i<MAX_DEVICES; i++)
    {
        for(j=0; j<MAX_MSG; j++)
        {
            for(k=0; k<MAX_DATA_SIZE; k++)
            {
                printf("0x%x, ",*((pConfig[i]->pTx[j])+k));
            }
            printf("\n");
        }
    }
}